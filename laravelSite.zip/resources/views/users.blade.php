<?php 
echo "<br>";
echo "public: ".public_path();
echo "<br>";
echo "base: ".base_path();
echo "<br>";
echo "storage: ".storage_path(); 
echo "<br>";
echo "app: ".app_path();
?>