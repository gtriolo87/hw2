<?php 

echo "only: ".path();
echo "<br>";
echo "public: ".public_path();
echo "<br>";
echo "base: ".base_path();
echo "<br>";
echo "storage: ".storage_path(); 
echo "<br>";
echo "app: ".app_path();
?><?php /**PATH C:\xampp\htdocs\hw2\resources\views/users.blade.php ENDPATH**/ ?>